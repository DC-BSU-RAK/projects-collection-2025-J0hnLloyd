package com.example.multi_page

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class CategoryQuotesActivity : AppCompatActivity() {

    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_quotes)

        listView = findViewById(R.id.listViewCategoryQuotes)

        val category = intent.getStringExtra("category") ?: ""

        val filteredQuotes = QuoteRepository.quotes.filter { it.category == category }

        val displayList = filteredQuotes.map { "\"${it.text}\" — ${it.author}" }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)
        listView.adapter = adapter

        title = category
    }
}
