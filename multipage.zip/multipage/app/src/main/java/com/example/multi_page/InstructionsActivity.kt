package com.example.multi_page

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class InstructionsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_instructions)

        val instructionsText = findViewById<TextView>(R.id.instructionsText)
        instructionsText.text = """
            
            
            
            
            
            
            
            How to Use This App:

            • Tap 'Generate Quote' to see a new inspirational quote.
            
            • Tap the star icon to save your favorite quotes.
            
            • Use the 'Categories' button to explore quotes by category.
            
            • Use the 'Favorites' button to view your saved quotes.

            Enjoy your daily inspiration!
        """.trimIndent()
    }
}
