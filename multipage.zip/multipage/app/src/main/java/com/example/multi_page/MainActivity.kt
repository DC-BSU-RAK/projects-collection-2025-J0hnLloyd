package com.example.multi_page

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.parcelize.Parcelize
import android.os.Parcelable
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var quoteText: TextView
    private lateinit var quoteAuthor: TextView
    private lateinit var btnNewQuote: Button
    private lateinit var btnSaveFavorite: ImageButton
    private lateinit var btnCategories: Button
    private lateinit var btnFavorites: Button
    private lateinit var btnInstructions: Button

    private var currentQuote: Quote? = null

    // SharedPreferences and Gson for persistence
    private lateinit var sharedPrefs: SharedPreferences
    private val gson = Gson()

    // Favorites list stored in memory
    private val favoritesList = mutableListOf<Quote>()

    private val quotes = listOf(
        Quote("Believe you can and you're halfway there.", "Theodore Roosevelt", "Motivation"),
        Quote("The only way to do great work is to love what you do.", "Steve Jobs", "Motivation"),
        Quote("Success is not final, failure is not fatal: It is the courage to continue that counts.", "Winston Churchill", "Inspiration"),
        Quote("Happiness is not something ready made. It comes from your own actions.", "Dalai Lama", "Philosophy"),
        Quote("Do or do not. There is no try.", "Yoda", "Wisdom"),
        Quote("All we have to decide is what to do with the time that is given us.", "Gandalf", "Fantasy"),
        Quote("Life is what happens when you're busy making other plans.", "John Lennon", "Philosophy"),
        Quote("I have not failed. I've just found 10,000 ways that won't work.", "Thomas Edison", "Persistence"),
        Quote("It's not our abilities that show what we truly are... it is our choices.", "Dumbledore", "Leadership"),
        Quote("The greatest glory in living lies not in never falling, but in rising every time we fall.", "Nelson Mandela", "Courage"),
        Quote("To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment.", "Ralph Waldo Emerson", "Individuality"),
        Quote("I'm not superstitious, but I am a little stitious.", "Michael Scott", "Humor"),
        Quote("In the middle of difficulty lies opportunity.", "Albert Einstein", "Inspiration"),
        Quote("You miss 100% of the shots you don't take.", "Wayne Gretzky", "Motivation"),
        Quote("A person who never made a mistake never tried anything new.", "Albert Einstein", "Creativity"),
        Quote("Even the darkest night will end and the sun will rise.", "Victor Hugo", "Hope"),
        Quote("Why do we fall, Bruce? So we can learn to pick ourselves up.", "Thomas Wayne", "Wisdom"),
        Quote("Fear is the path to the dark side. Fear leads to anger. Anger leads to hate. Hate leads to suffering.", "Yoda", "Mindfulness"),
        Quote("I am vengeance. I am the night. I am Batman!", "Batman", "Courage"),
        Quote("Not all those who wander are lost.", "J.R.R. Tolkien", "Adventure"),
        Quote("You have power over your mind — not outside events. Realize this, and you will find strength.", "Marcus Aurelius", "Philosophy"),
        Quote("Just keep swimming.", "Dory", "Encouragement"),
        Quote("With great power comes great responsibility.", "Uncle Ben", "Leadership"),
        Quote("The world isn't split into good people and Death Eaters.", "Sirius Black", "Reality"),
        Quote("Love is composed of a single soul inhabiting two bodies.", "Aristotle", "Love"),
        Quote("Imagination is more important than knowledge.", "Albert Einstein", "Creativity"),
        Quote("Courage is not the absence of fear, but rather the judgment that something else is more important than fear.", "Ambrose Redmoon", "Courage"),
        Quote("Sometimes it is the people no one can imagine anything of who do the things no one can imagine.", "Alan Turing", "Inspiration"),
        Quote("The past can hurt. But the way I see it, you can either run from it, or learn from it.", "Rafiki", "Growth"),
        Quote("Reality is often disappointing.", "Thanos", "Reality"),
        Quote("A lesson without pain is meaningless.", "Edward Elric", "Philosophy"),
        Quote("All dreams can come true, if we have the courage to pursue them.", "Walt Disney", "Motivation"),
        Quote("Some infinities are bigger than other infinities.", "Hazel Grace Lancaster", "Philosophy"),
        Quote("Do what you can, with what you have, where you are.", "Theodore Roosevelt", "Persistence"),
        Quote("Every great dream begins with a dreamer.", "Harriet Tubman", "Dreams"),
        Quote("Hope is a good thing, maybe the best of things.", "Andy Dufresne", "Hope")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        sharedPrefs = getSharedPreferences("quotes_prefs", Context.MODE_PRIVATE)
        loadFavorites()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        quoteText = findViewById(R.id.quoteText)
        quoteAuthor = findViewById(R.id.quoteAuthor)
        btnNewQuote = findViewById(R.id.btnNewQuote)
        btnSaveFavorite = findViewById(R.id.btnSaveFavorite)
        btnCategories = findViewById(R.id.btnCategories)
        btnFavorites = findViewById(R.id.btnFavorites)
        btnInstructions = findViewById(R.id.btnInstructions)

        showRandomQuote()

        btnNewQuote.setOnClickListener {
            showRandomQuote()
        }

        btnSaveFavorite.setOnClickListener {
            currentQuote?.let {
                if (!favoritesList.contains(it)) {
                    favoritesList.add(it)
                    saveFavorites()  // Save after adding
                }
            }
        }

        btnCategories.setOnClickListener {
            val intent = Intent(this, CategoriesActivity::class.java)
            startActivity(intent)
        }

        btnFavorites.setOnClickListener {
            val intent = Intent(this, FavoritesActivity::class.java)
            intent.putParcelableArrayListExtra("favorites", ArrayList(favoritesList))
            startActivity(intent)
        }

        btnInstructions.setOnClickListener {
            val intent = Intent(this, InstructionsActivity::class.java)
            startActivity(intent)
        }
    }

    private fun showRandomQuote() {
        currentQuote = quotes[Random.nextInt(quotes.size)]
        quoteText.text = "\"${currentQuote!!.text}\""
        quoteAuthor.text = "- ${currentQuote!!.author}"
    }

    // Save favorites list to SharedPreferences as JSON string
    private fun saveFavorites() {
        val json = gson.toJson(favoritesList)
        sharedPrefs.edit().putString("favorites_list", json).apply()
    }

    private fun loadFavorites() {
        val json = sharedPrefs.getString("favorites_list", null)
        if (json != null) {
            val type = object : TypeToken<MutableList<Quote>>() {}.type
            val listFromPrefs: MutableList<Quote> = gson.fromJson(json, type)
            favoritesList.clear()
            favoritesList.addAll(listFromPrefs)
        }
    }
}

@Parcelize
data class Quote(val text: String, val author: String, val category: String) : Parcelable
