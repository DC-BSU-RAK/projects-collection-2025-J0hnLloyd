package com.example.myapplication

import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var spinnerColor1: Spinner
    private lateinit var spinnerColor2: Spinner
    private lateinit var buttonMix: Button
    private lateinit var buttonInfo: ImageButton
    private lateinit var buttonReset: ImageButton


    private var gradientAnimator: ValueAnimator? = null

    private val colorList = listOf("Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        spinnerColor1 = findViewById(R.id.spinnerColor1)
        spinnerColor2 = findViewById(R.id.spinnerColor2)
        buttonMix = findViewById(R.id.buttonMix)
        buttonInfo = findViewById(R.id.buttonInfo)
        buttonReset = findViewById(R.id.buttonReset)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, colorList)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerColor1.adapter = adapter
        spinnerColor2.adapter = adapter

        setDefaultBackground()

        buttonMix.setOnClickListener {
            gradientAnimator?.cancel()
            val c1 = spinnerColor1.selectedItem.toString()
            val c2 = spinnerColor2.selectedItem.toString()
            setCustomGradientOrColor(c1, c2)
        }

        buttonInfo.setOnClickListener {
            showInfoDialog()
        }

        buttonReset.setOnClickListener {
            gradientAnimator?.cancel()
            setDefaultBackground()
        }
    }

    private fun setDefaultBackground() {
        val mainLayout = findViewById<View>(R.id.main)

        val orangeGradient = intArrayOf(
            0xFFFFA500.toInt(), // Orange
            0xFFFF8C00.toInt()  // Dark Orange
        )
        val gradient = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, orangeGradient)
        gradient.cornerRadius = 0f
        mainLayout.background = gradient

        gradientAnimator = null
    }

    private fun setCustomGradientOrColor(color1: String, color2: String) {
        val mainLayout = findViewById<View>(R.id.main)

        if (color1 == color2) {
            gradientAnimator?.cancel()
            mainLayout.setBackgroundColor(getColorValue(color1))
            return
        }

        val combo = setOf(color1, color2)
        val gradientColors = when (combo) {
            setOf("Red", "Orange") -> intArrayOf(Color.RED, 0xFFFFA500.toInt())
            setOf("Red", "Yellow") -> intArrayOf(Color.RED, Color.YELLOW)
            setOf("Red", "Green") -> intArrayOf(Color.RED, Color.GREEN)
            setOf("Red", "Blue") -> intArrayOf(Color.RED, Color.BLUE)
            setOf("Red", "Indigo") -> intArrayOf(Color.RED, 0xFF4B0082.toInt())
            setOf("Red", "Violet") -> intArrayOf(Color.RED, 0xFF8A2BE2.toInt())

            setOf("Orange", "Yellow") -> intArrayOf(0xFFFFA500.toInt(), Color.YELLOW)
            setOf("Orange", "Green") -> intArrayOf(0xFFFFA500.toInt(), Color.GREEN)
            setOf("Orange", "Blue") -> intArrayOf(0xFFFFA500.toInt(), Color.BLUE)
            setOf("Orange", "Indigo") -> intArrayOf(0xFFFFA500.toInt(), 0xFF4B0082.toInt())
            setOf("Orange", "Violet") -> intArrayOf(0xFFFFA500.toInt(), 0xFF8A2BE2.toInt())

            setOf("Yellow", "Green") -> intArrayOf(Color.YELLOW, Color.GREEN)
            setOf("Yellow", "Blue") -> intArrayOf(Color.YELLOW, Color.BLUE)
            setOf("Yellow", "Indigo") -> intArrayOf(Color.YELLOW, 0xFF4B0082.toInt())
            setOf("Yellow", "Violet") -> intArrayOf(Color.YELLOW, 0xFF8A2BE2.toInt())

            setOf("Green", "Blue") -> intArrayOf(Color.GREEN, Color.BLUE)
            setOf("Green", "Indigo") -> intArrayOf(Color.GREEN, 0xFF4B0082.toInt())
            setOf("Green", "Violet") -> intArrayOf(Color.GREEN, 0xFF8A2BE2.toInt())

            setOf("Blue", "Indigo") -> intArrayOf(Color.BLUE, 0xFF4B0082.toInt())
            setOf("Blue", "Violet") -> intArrayOf(Color.BLUE, 0xFF8A2BE2.toInt())

            setOf("Indigo", "Violet") -> intArrayOf(0xFF4B0082.toInt(), 0xFF8A2BE2.toInt())

            else -> null
        }

        if (gradientColors != null) {
            val gradient = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, gradientColors)
            gradient.cornerRadius = 0f
            mainLayout.background = gradient

            val shiftedColors = gradientColors.map { shiftHue(it, 30f) }.toIntArray()
            animateGradient(gradient, gradientColors, shiftedColors)
        } else {
            gradientAnimator?.cancel()
            mainLayout.setBackgroundColor(0xFFCCCCCC.toInt())
        }
    }

    private fun getColorValue(name: String): Int {
        return when (name) {
            "Red" -> Color.RED
            "Orange" -> 0xFFFFA500.toInt()
            "Yellow" -> Color.YELLOW
            "Green" -> Color.GREEN
            "Blue" -> Color.BLUE
            "Indigo" -> 0xFF4B0082.toInt()
            "Violet" -> 0xFF8A2BE2.toInt()
            else -> Color.GRAY
        }
    }

    private fun blendColors(from: Int, to: Int, ratio: Float): Int {
        val invRatio = 1f - ratio
        val a = (Color.alpha(from) * invRatio + Color.alpha(to) * ratio).toInt()
        val r = (Color.red(from) * invRatio + Color.red(to) * ratio).toInt()
        val g = (Color.green(from) * invRatio + Color.green(to) * ratio).toInt()
        val b = (Color.blue(from) * invRatio + Color.blue(to) * ratio).toInt()
        return Color.argb(a, r, g, b)
    }

    private fun shiftHue(color: Int, degrees: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[0] = (hsv[0] + degrees) % 360
        return Color.HSVToColor(Color.alpha(color), hsv)
    }

    private fun animateGradient(
        gradient: GradientDrawable,
        fromColors: IntArray,
        toColors: IntArray
    ) {
        gradientAnimator?.cancel()
        gradientAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000  // 1 second cycle
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE

            addUpdateListener { animator ->
                val fraction = animator.animatedFraction
                val blended = IntArray(fromColors.size) {
                    blendColors(fromColors[it], toColors[it], fraction)
                }
                gradient.colors = blended
            }

            start()
        }
    }

    private fun showInfoDialog() {
        val message = """
            🌈 Color Mixer Instructions 🌈

            1. Select two colors from the dropdowns.
            2. Tap 'Mix Colors' to see a gradient blend.
            3. If you select the same color, the background will be solid.
            4. Only ROYGBIV combinations are supported.

            Have fun experimenting with color blends!
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("How to Use")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}
